---
title: "{{ replace .Name "-" " " | title }}"
description:
date: {{ .Date }}
draft: false
# layout options are standard (default) or wide-body
layout: standard
show_title_as_headline: false
---
